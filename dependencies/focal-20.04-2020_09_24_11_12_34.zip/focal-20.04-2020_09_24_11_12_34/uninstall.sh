#!/bin/bash
sudo dpkg -r modelinterfacerbdl
sudo dpkg -r robotinterfaceros
sudo dpkg -r xbotinterface
sudo dpkg -r cartesian_interface
sudo dpkg -r matlogger2
sudo dpkg -r open_sot
sudo dpkg -r robot_monitoring
sudo dpkg -r xbot2
sudo dpkg -r xbot_msgs
